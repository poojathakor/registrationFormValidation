$(document).ready(function(){

/* ###################################################################################################
Registration Form Module
 ###################################################################################################*/
if($(".body_cls").find(".reg_form_cls").length !=0){
                var $select = $(".age");
                for (i=1;i<=100;i++){
                    $select.append($('<option></option>').val(i).html(i))
                }

                $("#reg_form").validate({
                rules: {
                    name: "required",
                    
                    gender: {
                       required: true
                    },
                    age: {
                       required: true
                    },
                    email: {
                        email: true,
                       require_from_group: [1, ".contact-grp"]

                    },
                    mobile: {
                        number: true,
                        maxlength: 12,
                        minlength: 10,
                        require_from_group: [1, ".contact-grp"]
                    },
                    options: {
                       required: true
                    },
                    hobby:{
                        required: true
                    }
               },
                messages: {
                    name: "Please enter your firstname",
                    
                    gender: {
                        required: "Please select your gender"
                    },
                    age: {
                        required: "Please provide your age" 
                    },
                    email: "Please enter a valid email address",
                    mobile: {
                        number: "mobile number must be numeric",
                        minlength: "mobile number must contain more than 10 digits",
                        maxlength: "mobile number must not contain less than 12 digits",
                        required: "Please provide your mobile number"
                    },
                    options: "Please select any one technology",
                    hobby: "Please enter your hobby"
               }
            });
        $( function() {
            var availableTags = [
            "Amateur radio",
            "Audiophilia",
            "Aquarium keeping",
            "Baking",
            "Baton twirling",
            "Bonsai",
            "Computer programming",
            "Cooking",
            "Creative writing",
            "Dance",
            "Drawing",
            "Basketball",
            "Genealogy",
            "Home automation",
            "Home movies",
            "Jewelry making",
            "Knapping",
            "Lapidary",
            "Locksport",
            "Musical instruments",
            "Painting",
            "Knitting",
            "Scrapbooking",
            "Sculpting",
            "Sewing",
            "Singing",
            "Woodworking",
            "Audiophilia",
            "Microscopy",
            "Reading",
            "Shortwave listening"
            ];
            function split( val ) {
                return val.split( /,\s*/ );
            }
            function extractLast( term ) {
                return split( term ).pop();
            }
         
            $( "#hobby" )
              // don't navigate away from the field on tab when selecting an item
                .on( "keydown", function( event ) {
                if ( event.keyCode === $.ui.keyCode.TAB &&
                    $( this ).autocomplete( "instance" ).menu.active ) {
                  event.preventDefault();
                }
              })
            .autocomplete({
                minLength: 0,
                source: function( request, response ) {
                  // delegate back to autocomplete, but extract the last term
                  response( $.ui.autocomplete.filter(
                    availableTags, extractLast( request.term ) ) );
                },
                focus: function() {
                  // prevent value inserted on focus
                  return false;
                },
                select: function( event, ui ) {
                  var terms = split( this.value );
                  // remove the current input
                  terms.pop();
                  // add the selected item
                  terms.push( ui.item.value );
                  // add placeholder to get the comma-and-space at the end
                  terms.push( "" );
                  this.value = terms.join( ", " );
                  return false;
                }
              });

            /* ###################################################### Dropdown with images ####################################################*/
            jQuery('.drop-down').append('<div class="button"></div>');    
            jQuery('.drop-down').append('<ul class="select-list" style="list-style:none;"></ul>');    
            jQuery('.drop-down select option').each(function() {  
                var bg = jQuery(this).css('background-image');    
                jQuery('.select-list').append('<li class="clsAnchor"><span value="' + jQuery(this).val() + '" class="' + jQuery(this).attr('class') + '" style=background-image:' + bg + '>' + jQuery(this).text() + '</span></li>');   
            });    
            jQuery('.drop-down .button').html('<span >' + jQuery('.drop-down select').find(':selected').text() + '</span>' + '<a href="javascript:void(0);" class="select-list-link"><i class="down"></i></a>').after('<input type="hidden" id="tec_hide">');   
            jQuery('.drop-down ul li').each(function() {   
            if (jQuery(this).find('span').text() == jQuery('.drop-down select').find(':selected').text()) {  
                jQuery(this).addClass('active');       
            }      
            });     
            jQuery('.drop-down .select-list span').on('click', function()
            {          
                var dd_text = jQuery(this).text();  
                var dd_img = jQuery(this).css('background-image'); 
                var dd_val = jQuery(this).attr('value');   
                jQuery('.drop-down .button').html('<span>' + dd_text + '</span>' + '<a href="javascript:void(0);" class="select-list-link"><i class="down"></i></a>');      
                $('#tec_hide').val(dd_text);

                jQuery('.drop-down .select-list span').parent().removeClass('active');    
                jQuery(this).parent().addClass('active');     
                $('.drop-down select[name=options]').val( dd_val ); 
                $('.drop-down .select-list li').slideUp();     
            });       
            jQuery('.drop-down .button').on('click','a.select-list-link', function()
            {      
                jQuery('.drop-down ul li').slideToggle();  
            });     
            /* ################################################################################################################################### */  
            // var i = 0
            // $(document).ready(function(){
            //         $(".hvr_cls"+i).hover(function(){
            //             // alert(".hvr_cls"+i);
            //         $(".error_tooltip"+i).css("display", "block");});
            //     i++;
            // });
           
        });

            function checktechselect()
           {
                    $('.drop-down >.button >a ').on('click',function(){
                        $('.select-error').removeClass("error");
                        $('.select-error').empty();
                    });

                   if($('#tec_hide').val()=='' || $('#tec_hide').val() =='--select--')
                   {
                     
                        $('.select-error').html('Please select technology').addClass("error");
                   }  
                   // else{
                   //      $('.select-error').removeClass("error");
                   // }
           }    
            $('#reg_form').submit(function()
            {
                checktechselect();
            });
        /* ################################################################ Tooltip code ########################################################*/
        var tooltips = $( "[title]" ).tooltip({
             position: {
               my: "left top",
               at: "right+5 top-5",
               collision: "none"
            }
        });
}
});